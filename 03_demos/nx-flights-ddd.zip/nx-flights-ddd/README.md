# NxFlights

Workshop example using Nx and DDD.

## Dummies

Please note that this repo contains some dummy projects used to demonstrate the ideas of DDD and Nx:

- boarding-*
- shared-util-auth

The other projects contain logic used in the application.