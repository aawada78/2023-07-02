import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BoardingDomainModule } from '@nx-flights/boarding/domain';
import { SharedUtilAuthModule } from '@nx-flights/shared/util-auth';

@NgModule({
  imports: [
    CommonModule, 
    BoardingDomainModule, 
    SharedUtilAuthModule,
  ]
})
export class BoardingFeatureModule {}
