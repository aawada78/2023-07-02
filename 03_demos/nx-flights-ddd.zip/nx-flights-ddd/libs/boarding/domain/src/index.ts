export * from './lib/boarding-domain.module';
