import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlightService } from './infrastructure/flight.service';
// import { BoardingDomainModule } from '@nx-flights/boarding/domain';

@NgModule({
  imports: [
    CommonModule
  ]
})
export class BookingDomainModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: BookingDomainModule,
      providers: [
        FlightService
      ]
    }
  }
}