# booking-api

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test booking-api` to execute the unit tests.
