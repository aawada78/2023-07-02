# shared-ui-common

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test shared-ui-common` to execute the unit tests.
