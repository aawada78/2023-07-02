import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { SharedUiCommonModule } from '@nx-flights/shared/ui-common';

@NgModule({
  imports: [
    CommonModule, 
    // SharedUiCommonModule
  ]
})
export class SharedUtilAuthModule {}
