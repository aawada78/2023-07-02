export interface Passenger {
    id: number;
    firstName: string,
    name: string;
    bonusMiles: number;
    passengerStatus: string;
}