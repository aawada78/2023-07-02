// Public API

export * from './feature-manage.component';
