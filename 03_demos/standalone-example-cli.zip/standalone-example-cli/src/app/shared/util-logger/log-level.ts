export enum LogLevel {
    DEBUG =  0,
    INFO = 1,
    ERROR = 2
}

