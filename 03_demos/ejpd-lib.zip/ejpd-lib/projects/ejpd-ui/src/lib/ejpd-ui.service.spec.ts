import { TestBed } from '@angular/core/testing';

import { EjpdUiService } from './ejpd-ui.service';

describe('EjpdUiService', () => {
  let service: EjpdUiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EjpdUiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
