import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EjpdUiComponent } from './ejpd-ui.component';

describe('EjpdUiComponent', () => {
  let component: EjpdUiComponent;
  let fixture: ComponentFixture<EjpdUiComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EjpdUiComponent]
    });
    fixture = TestBed.createComponent(EjpdUiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
