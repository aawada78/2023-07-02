import { NgModule } from '@angular/core';
import { EjpdUiComponent } from './ejpd-ui.component';



@NgModule({
  declarations: [
    EjpdUiComponent
  ],
  imports: [
  ],
  exports: [
    EjpdUiComponent
  ]
})
export class EjpdUiModule { }
