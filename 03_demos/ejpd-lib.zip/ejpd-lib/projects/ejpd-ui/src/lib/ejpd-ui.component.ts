import { Component } from '@angular/core';

@Component({
  selector: 'lib-ejpd-ui',
  template: `
    <p>
      ejpd-ui works!
    </p>
  `,
  styles: [
  ]
})
export class EjpdUiComponent {

}
